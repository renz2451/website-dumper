let interval = null;
let defaultFolder = "";

document.getElementById('dumpForm').onsubmit = async function(e) {
  e.preventDefault();
  const form = e.target;
  const data = {
    url: form.url.value,
    depth: form.depth.value || '0',
    rate: form.rate.value || 'unlimited',
    wait: form.wait.value || '1'
  };

  document.getElementById("logArea").innerHTML = "⏳ Preparing download...";
  const res = await fetch('/dump', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  });

  const result = await res.json();
  if (result.status === 'started') {
    defaultFolder = result.default;
    interval = setInterval(fetchLogs, 1000);
  }
};

async function fetchLogs() {
  const res = await fetch('/logs');
  const data = await res.json();
  const logDiv = document.getElementById("logArea");
  logDiv.innerHTML = "";
  data.logs.forEach(l => {
    const entry = document.createElement("div");
    entry.textContent = l;
    logDiv.appendChild(entry);
  });
  logDiv.scrollTop = logDiv.scrollHeight;

  if (data.logs.some(l => l.includes("FINISHED")) || data.logs.length > 0 && data.logs[data.logs.length - 1].includes('100%')) {
    clearInterval(interval);
    promptRename();
  }
}

function promptRename() {
  const newName = prompt("✅ Dump complete! Rename folder before saving to /sdcard/Download?", defaultFolder) || defaultFolder;
  fetch('/rename_and_move', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ old: defaultFolder, new: newName })
  })
  .then(res => res.json())
  .then(data => {
    if (data.status === 'success') {
      document.getElementById("logArea").innerHTML += `<br><br>✅ Saved to /sdcard/Download/${newName}<br><a href="${data.url}">📂 Open index.html</a>`;
    } else {
      document.getElementById("logArea").innerHTML += `<br>❌ Error: ${data.message}`;
    }
  });
}
